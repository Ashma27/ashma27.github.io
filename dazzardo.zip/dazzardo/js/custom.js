// Fixed Header Start
$(window).scroll(function () {
    
    if ($(window).scrollTop() >= 1) {
        $('.header').addClass('fixedHeader');
    } else {
        $('.header').removeClass('fixedHeader');
    }
});
// Fixed Header End

//   Scroll to Top Start
$(document).ready(function(){
    $('.backTop a').on('click', function(){
        $("html, body").animate({ scrollTop: 0 }, "slow");
    });
});
//   Scroll to Top End

// Company Roadmap Start
$(document).ready(() => {
    $('.tl_btns li .pointerBox').click(function () {
        $('.tl_c-w .tl_c').removeClass('active').eq($(this).index()).addClass('active');
    });

    (function ($) {
        function mediaSize() {
            /* desktop funciton */
            if (window.matchMedia('(min-width: 320px)').matches) {
                $('.tl_btns li.active').prevAll().addClass('active');
                $('.tl_c-w .tl_c').eq(this).addClass('active');
                $('.tl_btns li .pointerBox').click(function () {
                    $('.tl_btns li').removeClass('original-active');
                    $(this).parents('.tl_btns li').addClass('active original-active');
                    $(this).parents('.tl_btns li').prevAll().addClass('active');
                    $(this).parents('.tl_btns li').nextAll().removeClass('active');
                });
                $('.tl_btns li').last().find('.pointerBox').click(() => {
                    $('.tl_btns').addClass('last');
                });
                $('.tl_btns li .pointerBox').click(function () {
                    if ($(this).is(':last-child')) {
                        $('.tl_btns').addClass('last');
                    }
                    else {
                        $('.tl_btns').removeClass('last');
                    }
                });
            }
            /* mobile funciton */
            else {
                $('.tl_btns li.active').not(':last').removeClass('active');
                $('.tl_btns li .pointerBox').click(function () {
                    $('.tl_btns li').removeClass('active');
                    $(this).addClass('active');
                });
            }
        }
        mediaSize();
        window.addEventListener('resize', mediaSize, false);
    }(jQuery));
});
// Company Roadmap End