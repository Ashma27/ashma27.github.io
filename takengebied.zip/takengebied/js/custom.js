//   Video Slider Start
(function($) {
    $(document).ready(function($) {

      $(".slick").on("beforeChange", function(event, slick) {
        var currentSlide, slideType, player, command;
        
        //find the current slide element and decide which player API we need to use.
        currentSlide = $(slick.$slider).find(".slick-current");
        
        //determine which type of slide this, via a class on the slide container. This reads the second class, you could change this to get a data attribute or something similar if you don't want to use classes.
        slideType = currentSlide.attr("class").split(" ")[1];
        
        //get the iframe inside this slide.
        player = currentSlide.find("iframe").get(0);
        
        if (slideType == "vimeo") {
          command = {
            "method": "pause",
            "value": "true"
          };
        } else {
          command = {
            "event": "command",
            "func": "pauseVideo"
          };
        }
        
        //check if the player exists.
        if (player != undefined) {
          //post our command to the iframe.
          player.contentWindow.postMessage(JSON.stringify(command), "*");
        }
      });
      
      //start the slider
      
      //run the fitVids jQuery plugin to ensure the iframes stay within the item.
      $('.item').fitVids();
      
    });
});

$(document).ready(function(){
    $(".slick").slick({
        infinite: false,
        arrows: true,
        dots: false,
    });

    $('.modal').on('shown.bs.modal', function (e) {
        $('.slick').resize();
    });
});

// Video Slider Start

// Sidebar Start

$('.navbar-toggler').click(function () {
    if ($(window).width() > 1367) {
        if ($(this).parents('.navbar').find('.navbar-collapse').hasClass('show')) {
            $('.navbar-expand-md .navbar-collapse').css('left', '-466px');
        } else {
            $('.navbar-expand-md .navbar-collapse').css('left', '0px');
        }
    }
    else if ($(window).width() > 992) {
        if ($(this).parents('.navbar').find('.navbar-collapse').hasClass('show')) {
            $('.navbar-expand-md .navbar-collapse').css('left', '-330px');
        } else {
            $('.navbar-expand-md .navbar-collapse').css('left', '0px');
        }
    }
    else if ($(window).width() > 561) {
        if ($(this).parents('.navbar').find('.navbar-collapse').hasClass('show')) {
            $('.navbar-expand-md .navbar-collapse').css('left', '-275px');
        } else {
            $('.navbar-expand-md .navbar-collapse').css('left', '0px');
        }
    }
    else{
        if ($(this).parents('.navbar').find('.navbar-collapse').hasClass('show')) {
            $('.navbar-expand-md .navbar-collapse').css('left', '-100%');
        } else {
            $('.navbar-expand-md .navbar-collapse').css('left', '0px');
        }
    }
    
});
  
// Sidebar End

// Navbar Button Style Start

$(document).ready(function(){
    $('.navbar-toggler').click(function(){
        if($(this).hasClass('active'))
        {
            $(this).removeClass('active')
        }
        else{
            $(this).addClass('active')
        }
    });
});
  
// Navbar Button Style End


$(document).ready(function(){
    $('.navbar-toggler').on('click', function(){
        $(this).parents('body').toggleClass('menuOpen');
    });
});


