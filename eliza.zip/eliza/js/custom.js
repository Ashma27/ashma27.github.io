// Fixed Header Start

    $(window).scroll(function () {
    
        if ($(window).scrollTop() >= 1) {
            $('.header').addClass('fixedHeader');
        } else {
            $('.header').removeClass('fixedHeader');
        }
    });
  
  // Fixed Header End

    $(document).ready(function(){
        $('.homeSlider').slick({
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: true,
        fade:true,
        dots: false,
        slidesToShow: 1,
        infinite: true,
        speed: 1000,
        slidesToShow: 1,
	    slidesToScroll: 1,
        adaptiveHeight: false,
        });
    });
    $(document).ready(function(){
        $('.selectedSlider').slick({
        autoplay: true,
        autoplaySpeed: 2000,
        arrows: true,
        fade:false,
        dots: false,
        slidesToShow: 1,
        infinite: true,
        speed: 1000,
        slidesToShow: 3,
	    slidesToScroll: 1,
        adaptiveHeight: false,
        });
    });

  // Sidebar Start

    $('.navbar-toggler').click(function () {
        if ($(this).parents('.navbar').find('.navbar-collapse').hasClass('show')) {
            $('.navbar-expand-md .navbar-collapse').css('left', '-250px');
        } else {
            $('.navbar-expand-md .navbar-collapse').css('left', '0px');
        }
    });
  
  // Sidebar End

  

  // Navbar Button Style Start

    // $(document).ready(function(){
    //     $('.navbar-toggler').click(function(){
    //         if($(this).hasClass('active'))
    //         {
    //             $(this).removeClass('active')
    //         }
    //         else{
    //             $(this).addClass('active')
    //         }
    //     });
    // });
  
  // Navbar Button Style End


// Cart Counter Start

$(".plusBtn").on("click", function() {
    var $n = $(this).parent(".vaulebox").find(".qty");
    $n.val(Number($n.val()) + 1);
});

$(".minusBtn").on("click", function() {
    var $n = $(this).parent(".vaulebox").find(".qty");
    var amount = Number($n.val());
    if (amount > 0) {
        $n.val(amount - 1);
    }
});

// Cart Counter End

// Modal Contact Number With Flag and Country Code Start

var input = document.querySelector("#phone");
window.intlTelInput(input, {
    nationalMode: false,
    utilsScript: "js/utils.js",
});

$('#phone').click(function() {
    var elmcode = $(this).prev('.iti__flag-container').find('ul.iti__country-list').find('.iti__active').find(".iti__dial-code").text();
    $(this).val(elmcode + ' - ');
});

// Modal Contact Number With Flag and Country Code End

// Modal Open/Close Start

$('.onLoginModal').on("click", function (){
    $('#loginModal').modal('show');
    $('#signupModal').modal('hide');
});

$('.onPasswordModal').on("click", function (){
    $('#loginModal').modal('hide');
    $('#passwordModal').modal('show');
});

$('.onSignupModal').on("click", function (){
    $('#loginModal').modal('hide');
    $('#signupModal').modal('show');
});

// Modal Open/Close End







//Wishlist Start

$(document).on('click', '#addWishlist', function (evt) {
    evt.preventDefault();
    if ($(this).hasClass('heartColor')) {
        $(this).removeClass('heartColor');
        $(".wishBox span").html("Removed from your wishlist!. ");
    } else {
        $(this).addClass('heartColor');
        $(".wishBox span").html("Added to your wishlist!. ");
    }
    $(".wishBox").fadeIn();
    $(".wishBox").fadeOut(2000);

});

//Wishlist End