$(window).scroll(function () {
    
    if ($(window).scrollTop() >= 1) {
        $('.header').addClass('fixedHeader');
    } else {
        $('.header').removeClass('fixedHeader');
    }
});


AOS.init({
    duration: 1200,
    once: false
  })