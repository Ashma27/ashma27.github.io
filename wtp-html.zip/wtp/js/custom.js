$('.slider').slick({
    dots: false,
    arrows: true,
    autoplay: true,
    autoplaySpeed: 3000,
    infinite: false,
    speed: 1000,
    slidesToShow: 2.4,
    adaptiveHeight: false,

    responsive: [{
                    breakpoint:991,
                        settings: {
                        slidesToShow: 2.1,
                }},

            {
                    breakpoint: 767,
                        settings: {
                        slidesToShow: 1.5,
                }},

            {
                    breakpoint: 561,
                        settings: {
                        slidesToShow: 1.2,
                }},

            {
                    breakpoint: 560,
                        settings: {
                        slidesToShow: 1,
                }},

            ]

});

$(window).scroll(function () {
    if ($(window).scrollTop() >= 1) {
        $('.header').addClass('fixed_header');
    }
    else {
        $('.header').removeClass('fixed_header');
    }
});


var forEach = function (t, o, r) {
    if ("[object Object]" === Object.prototype.toString.call(t))
        for (var c in t)
            Object.prototype.hasOwnProperty.call(t, c) && o.call(r, t[c], c, t);
    else
        for (var e = 0, l = t.length; l > e; e++)
            o.call(r, t[e], e, t)
};

var hamburgers = document.querySelectorAll(".hamburger");
if (hamburgers.length > 0) {
    forEach(hamburgers, function (hamburger) {
        hamburger.addEventListener("click", function () {
            this.classList.toggle("is-active");
        }, false);
    });
}

$('.hamburger').click(function () {

    if ($(this).hasClass('is-active')) {
        $('#mySidenav').css('left', '0px');
    }
    else {
        $('#mySidenav').css('left', '-250px');
        $('#mySidenav').css('top', '85px');
    }
});


$(document).ready(function (){
    $('.all').hide();
    $('.all1').show();
    $('.clickhere').click(function (){
        var type = $(this).data('type');
        $('.all').hide();
        $('.all' + type).fadeIn();
        $('.clickhere').removeClass('active');
        $(this).addClass('active'); 
        });
});

$('.slider2').slick({
    dots: true,
    arrows: false,
    autoplay: true,
    autoplaySpeed: 3000,
    infinite: false,
    speed: 1000,
    slidesToShow: 1,
    adaptiveHeight: false,
});

if ($(window).width() <= 767) {
    $('.ourmotto_left').insertAfter($('.ourmotto_right'));
}