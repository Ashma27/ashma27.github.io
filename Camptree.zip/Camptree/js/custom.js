(function ( $ ) {
  $.fn.progress = function() {
    var percent = this.data("percent");
    this.css("width", percent+"%");
  };
}( jQuery ));

$(document).ready(function(){
  $(".bar-one .bar").progress();

});


var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight){
      panel.style.maxHeight = null;
    } else {
      panel.style.maxHeight = panel.scrollHeight + "px";
    } 
  });
}

var count=1;
$('.accordion').click(function() {
    if(count==1){
        $(this).html('');
        $(this).html('Hide Rewards');
         $('#pan').css({"maxHeight":"185px","border":"1px solid #e4e4e4","margin":"25px 0","height":"200px"});
        count++;    
    }else{
        $(this).html('');
        $(this).html('See Rewards');
        $('#pan').css({"border":"1px solid transparent","box-shadow":"none","margin":"0"});
        count=1;
    }
});


$('#copy-text').dblclick(function(){
    $(this).focus();
     $(this).select();
     document.execCommand('copy');
});