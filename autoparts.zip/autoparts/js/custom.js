//Wishlist Start

$(document).on('click', '#addWishlist', function (evt) {
    evt.preventDefault();
    if ($(this).hasClass('heartColor')) {
        $(this).removeClass('heartColor');
        $(".wishBox span").html("Removed from your wishlist!. ");
    } else {
        $(this).addClass('heartColor');
        $(".wishBox span").html("Added to your wishlist!. ");
    }
    $(".wishBox").fadeIn();
    $(".wishBox").fadeOut(2000);

});

//Wishlist End
// Hide / Show header Searchbar Start

$('.toggleSearch').on("click", function(){
    if($(this).parent('.searchBox').hasClass('openSearch'))
    {
        $(this).parent('.searchBox').removeClass('openSearch');
    }
    else{
        $(this).parent('.searchBox').addClass('openSearch');
    }
});

$(document).on("click", function (event) {
    var $trigger = $(".header .searchBox");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
        $('.searchBox').removeClass('openSearch');
    }
});


if($(window).width() < 561)
{
    $('.toggleSearch').on("click", function(){
        if($('.header').hasClass('openSearch1'))
        {
            $('.header').removeClass('openSearch1');
        }
        else{
            $('.header').addClass('openSearch1');
        }
    });
    
    $(document).on("click", function (event) {
        var $trigger = $(".header .searchBox.searchMobile");
        if ($trigger !== event.target && !$trigger.has(event.target).length) {
            $('.searchBox.searchMobile').removeClass('openSearch1');
        }
    });
} 

// Hide / Show header Searchbar End
// header signup dropdown 
$('.drop_down button').click(function() {
    $('.flgmenu').slideToggle();
});
$('.signup_drop_main a').click(function() {
    $('.signup_drop').slideToggle();
});

$('.flgmenu li').click(function() {
    var elmpath = $(this).children('img').attr("src");
    var txt = $(this).text();
    $(this).parents('ul.flgmenu').prevAll('button').find('span').text(txt);
    $(this).parents('ul.flgmenu').prevAll('button').find('img').attr('src', elmpath);
    $(this).parents('ul.flgmenu').slideUp();
});

$(document).on("click", function(event) {
    var $trigger = $(".drop_down button");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
        $("ul.flgmenu").slideUp("fast");
    }
});
// header signup dropdown End



$(document).ready(function() {
$('.inntabbx ul li').click(function() {
    var comTab = $(this).attr('data-tag');
    $('.commTabS').removeClass('showCmmTab');
    $('#' + comTab).addClass('showCmmTab');
});

$('.inntabbx ul li ').click(function() {
    $('.inntabbx ul li ').removeClass('active');
    $(this).addClass('active');
});
});
$(document).ready(function() {
    $('.adsbx_in .loadSec:hidden').slice(0, 9).show();
    $('.btn_load').click(function() {
        $('.adsbx_in .loadSec:hidden').slice(0, 3).slideDown();
        if ($('.adsbx_in .loadSec:hidden').length === 0) {
            $('.btn_load').fadeOut('fast');
        }
    });
});
$(document).ready(function() {
$('.tab_menu li').click(function() {
    var tabVal = $(this).attr('data-tag');
    $('.tab_menu li').removeClass('active');
    $(this).addClass('active');
    $('.adsbx_in').removeClass('showTabSec');
    $('#' + tabVal).addClass('showTabSec');
});
});


$(document).ready(function() {
$('.dropBox button').click(function() {
    $('.dropBox .dropCntnt').slideToggle();

});

$('.dropBox .dropCntnt li').click(function() {
    $(this).parent('ul').slideUp();
    var elmTxtt = $(this).text();
    $('.dropBox button span').text(elmTxtt);
});
});

$(document).on("click", function(event) {
    var $trigger = $(".dropBox");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
        $(".dropBox .dropCntnt").slideUp("fast");
    }
});
$(document).ready(function() {
$(window).scroll(function() {
    if ($(window).scrollTop() >= 45) {
        $('.header').addClass('fixed_header');
    } else {
        $('.header').removeClass('fixed_header');
    }
});
var forEach = function(t, o, r) {
    if ("[object Object]" === Object.prototype.toString.call(t))
        for (var c in t)
            Object.prototype.hasOwnProperty.call(t, c) && o.call(r, t[c], c, t);
    else
        for (var e = 0, l = t.length; l > e; e++)
            o.call(r, t[e], e, t)
};
});
$(document).ready(function() {
var hamburgers = document.querySelectorAll(".hamburger");
if (hamburgers.length > 0) {
    forEach(hamburgers, function(hamburger) {
        hamburger.addEventListener("click", function() {
            this.classList.toggle("is-active");
        }, false);
    });
}

$('.hamburger').click(function() {

    if ($(this).hasClass('is-active')) {
        $('#mySidenav').css('left', '0px');
    } else {
        $('#mySidenav').css('left', '-250px');
    }
});

$('.arrowdwn').click(function() {
    $('html,body').animate({
        scrollTop: $('.searchImg').offset().top - 80
    }, 500);
});

$('.chatBx a').click(function() {
    $('.chat_bar').css('right', '0');
    $('.adsbx_in').addClass('moveSide');
});

$('.chat_bar .chat_bar_in h2 i').click(function() {
    $('.chat_bar').css({
        'right': '-100%',
        'trnasition': 'all 1s'
    });

    $('.adsbx_in').removeClass('moveSide');
});

$('.drop_down button').click(function() {
    $('.flgmenu').slideToggle();
});
$('.signup_drop_main a').click(function() {
    $('.signup_drop').slideToggle();
});

$('.flgmenu li').click(function() {
    var elmpath = $(this).children('img').attr("src");
    var txt = $(this).text();
    $(this).parents('ul.flgmenu').prevAll('button').find('span').text(txt);
    $(this).parents('ul.flgmenu').prevAll('button').find('img').attr('src', elmpath);
    $(this).parents('ul.flgmenu').slideUp();
});
});
$(document).on("click", function(event) {
    var $trigger = $(".drop_down button");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
        $("ul.flgmenu").slideUp("fast");
    }
});

// signup tab start 
$('.singup_slider').slick({
    dots: true,
    arrows: false,
    autoplay: false,
    autoplaySpeed: 3000,
    infinite: true,
    speed: 1500,
    slidesToScroll: 1,
    slidesToShow: 1,
    adaptiveHeight: true,
});
$('.signup_headimg a').click(function() {
    var sTab = $(this).attr('data-tag');
    $('.signup_headimg a').removeClass('active');
    $(this).addClass('active');
    $('.form_field').removeClass('showform');
    $("#" + sTab).addClass('showform');
});
$(function() {
    $('input[type=file]').change(function(){
      var t = $(this).val();
      var labelText = 'File : ' + t.substr(12, t.length);
      $(this).prev('label').text(labelText);
    })
  });
// signup tab END 

// details page 
$('.pslider').slick({
    dots: true,
    arrows: false,
    autoplay: false,
    autoplaySpeed: 3000,
    infinite: true,
    speed: 1500,
    slidesToScroll: 1,
    slidesToShow: 1,
    adaptiveHeight: true,
});
// details page End