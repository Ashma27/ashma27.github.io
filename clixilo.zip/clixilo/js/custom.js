// fixed header start
$(window).scroll(function () {
    if ($(window).scrollTop() >= 55) {
        $('.header').addClass('fixed_header');
    }
    else {
        $('.header').removeClass('fixed_header');
    }
}); 
var forEach = function (t, o, r) {
    if ("[object Object]" === Object.prototype.toString.call(t))
        for (var c in t)
            Object.prototype.hasOwnProperty.call(t, c) && o.call(r, t[c], c, t);
    else
        for (var e = 0, l = t.length; l > e; e++)
            o.call(r, t[e], e, t)
};
// fixed header end

// hamburger start
var hamburgers = document.querySelectorAll(".hamburger");
if (hamburgers.length > 0) {
    forEach(hamburgers, function (hamburger) {
        hamburger.addEventListener("click", function () {
            this.classList.toggle("is-active");
        }, false);
    });
}

$('.hamburger').click(function () {
        $('#mySidenav').css('right', '0px');
        $('.hamburger2').addClass('is-active');
});
$('.hamburger2').click(function () {
        $('#mySidenav').css('right', '-100%');
        $('.hamburger2').removeClass('is-active');
        $('.hamburger').removeClass('is-active');
});
// hamburger end

//accodian start
var $activePanelHeading = $('.panel-group .panel .panel-collapse.in').prev().addClass('active');  //add class="active" to panel-heading div above the "collapse in" (open) div
    $activePanelHeading.find('a').prepend('<i class="fa fa-plus"></i> ');  
    //put the minus-sign inside of the "a" tag
    $('.panel-group .panel-heading').not($activePanelHeading).find('a').append('<i class="fa fa-plus accordian_faq font_icon"></i> ');  //if it's not active, it will put a plus-sign inside of the "a" tag
        $('.panel-group').on('show.bs.collapse', function (e) {  
            //event fires when "show" instance is called
            //$('.panel-group .panel-heading.active').removeClass('active').find('.fa').toggleClass('fa-plus fa-minus'); - removed so multiple can be open and have minus sign
        $(e.target).prev().addClass('active').find('.accordian_faq').toggleClass('fa fa-plus fa fa-times');
    });
        $('.panel-group').on('hide.bs.collapse', function (e) {  
            //event fires when "hide" method is called
        $(e.target).prev().removeClass('active').find('.accordian_faq').removeClass('fa fa-times').addClass('fa fa-plus');
});
//accordian close