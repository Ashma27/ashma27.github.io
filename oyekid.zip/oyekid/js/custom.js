
// Dropbox Menu Start

$(document).ready(function(){
    $('.openUserMenu').on('click', function(){
        if($(this).hasClass('menuOpen')){
            $(this).removeClass('menuOpen');
            $(this).parents('.menuLogin').find('.menuDropbox').slideUp(200);
        }
        else{
            $('.openUserMenu').removeClass('menuOpen');
            $('.openUserMenu').parents('.menuLogin').find('.menuDropbox').slideUp(200);
            $(this).addClass('menuOpen');
            $(this).parents('.menuLogin').find('.menuDropbox').slideDown(200);
        }
    });

    $(document).on("click", function (event) {
        var $trigger = $(".menuLogin");
        if ($trigger !== event.target && !$trigger.has(event.target).length) {
            $('.openUserMenu').removeClass('menuOpen');
            $('.openUserMenu').parents('.menuLogin').find('.menuDropbox').slideUp('fast');
        }
    });

});
// Dropbox Menu End
// Hide/Show Modals Start
$(document).ready(function(){
    $('.onLoginBtn').on('click', function(){
        $('#loginModal').modal('show');
    });
});
$(document).ready(function(){
    $('.onSignIn').on('click', function(){
        $('#loginModal').modal('hide');
        $(this).parents('body').addClass('modals-open');
        $('#verificationModal').modal('show');
    });
});
$(document).ready(function(){
    $('.onOtpSubmit').on('click', function(){
        $('#verificationModal').modal('hide');
        $(this).parents('body').addClass('modals-open');
        $('#compProfileModal').modal('show');
    });
});
$(document).ready(function(){
    $('.onSelectType').on('click', function(){
        $('#whyHere').modal('hide');
        $(this).parents('body').addClass('modals-open');
        $('#compProfileModal').modal('show');
    });
});
// Hide/Show Modals End
// add class 
$(".likeClick").on('click', function(){
    $(this).addClass("active");
});
// add class END 

// follow & following start
function followDating( iCol ) {
    $(this).text(function(_, text) {
        return text === 'Following' ? 'Follow' : 'Following';
    });
    $(this).toggleClass('followActive');
} 
  //follow & following END

// User Profile Image Upload Start
$(document).ready(function(){
    var readURL = function(input){
        if (input.files && input.files[0]){
            var reader = new FileReader();
            reader.onload = function (e){
                $('.profile-pic').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $(".file-upload").on('change', function(){
        readURL(this);
        $('.upload-button').addClass('active');
    });
    $(".upload-button").on('click', function() {
       $(".file-upload").click();
    });
});
// User Profile Image Upload Start

// Hide and show recordBox Start
$(document).ready(function(){
    $('.hideShowBox').on('click', function(){
        $(this).parent('.addAddempty').css('display', 'none');
        $(this).parents('.addRecordsBox').find('.showRecord').css('display', 'block');
    });
    $('.hideShowBox2').on('click', function(){
        $(this).parents('.addRecordsBox').find('.showRecord').css('display', 'none');
        $(this).parents('.bookApp').addClass('active'); //new as
    });
    $('.hideShowBox3').on('click', function(){
        $(this).parents('.addRecordsBox').find('.showRecord2').css('display', 'none');
        $(this).parents('.addRecordsBox').find('.showRecord3').css('display', 'block'); //new as
    });
    $('.editHide a').on('click', function(){
        $(this).parents('.MakeofferTabs').find('.editHide').css('display', 'none');
        $(this).parents('.MakeofferTabs').find('.editShow').css('display', 'inline-block'); //new as
    });
});
// Hide and show recordBox End

// Div show after radio selected start
$(document).ready(function() {
     // payment Method
     $('input[name=paymentMethod][type="radio"]').click(function() {
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $("#enterCVV").not(targetBox).slideUp();
        $("#enterCVV2").not(targetBox).slideUp();
        $("#enterCVV3").not(targetBox).slideUp();
        $("#showCCForm").not(targetBox).slideUp();
        $("#showCDForm").not(targetBox).slideUp();
        $(targetBox).slideDown();
    });
});
// Div show after radio selected ENd

// Fixed Header Start
    $(window).scroll(function () {
        if ($(window).scrollTop() >= 1) {
            $('.header').addClass('fixedHeader');
        } else {
            $('.header').removeClass('fixedHeader');
        }
    });
// Fixed Header End

// Sidebar Start
$('.navbar-toggler').on('click', function () {
    if ($(this).parents('.navbar').find('.navbar-collapse').hasClass('show')) {
        $('.navbar-expand-md .navbar-collapse').css('left', '-250px');
    } else {
        $('.navbar-expand-md .navbar-collapse').css('left', '0px');
    }
});
// Sidebar End

// Navbar Button Style Start
$(document).ready(function(){
    $('.navbar-toggler').click(function(){
        if($(this).hasClass('active'))
        {
            $(this).removeClass('active')
        }
        else{
            $(this).addClass('active')
        }
    });
});
// Navbar Button Style End
//  Products Slider Start 
$(document).ready(function(){
    $('.proSlider').slick({
    autoplay: false,
    autoplaySpeed: 1000,
    arrows: true,
    dots: false,
    slidesToShow: 4,
    infinite: false,
    responsive: [
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 3
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 2
            }
        },
        {
            breakpoint: 561,
            settings: {
                slidesToShow: 2
            }
        }]
    });
});
//  Products Slider End

// Otp Function Start

$(document).ready(function(){
    $('.otpForm').find('input').each(function() {
        $(this).attr('maxlength', 1);
        $(this).on('keyup', function(e) {
            var parent = $($(this).parent());
            
            if(e.keyCode === 8 || e.keyCode === 37) {
                var prev = parent.find('input#' + $(this).data('previous'));
                if(prev.length) {
                    $(prev).select();
                }
            }if((e.keyCode >= 48 && e.keyCode <= 57) || e.keyCode === 39) {
                var next = parent.find('input#' + $(this).data('next'));
                
                if(next.length) {
                    $(next).select();
                } else {
                    if(parent.data('autosubmit')) {
                        parent.submit();
                    }
                }
            }
            else if((e.keyCode >= 65 && e.keyCode <= 90 ) || (e.keyCode >= 97 && e.keyCode <= 122)){
                alert('character'); 
            }
        });
    });
});

// Otp Function End

// Modal Contact Number With Flag and Country Code Start

var input = document.querySelector("#phoneNumber");
window.intlTelInput(input, {
    nationalMode: false,
    utilsScript: "js/utils.js",
});

$('#phoneNumber').click(function() {
    var elmcode = $(this).prev('.iti__flag-container').find('ul.iti__country-list').find('.iti__active').find(".iti__dial-code").text();
    $(this).val(elmcode + ' - ');
});

// Modal Contact Number With Flag and Country Code End


// Hide / Show header Searchbar Start

$('.toggleSearch').on("click", function(){
    if($(this).parent('.searchBox').hasClass('openSearch'))
    {
        $(this).parent('.searchBox').removeClass('openSearch');
    }
    else{
        $(this).parent('.searchBox').addClass('openSearch');
    }
});

$(document).on("click", function (event) {
    var $trigger = $(".header .searchBox");
    if ($trigger !== event.target && !$trigger.has(event.target).length) {
        $('.searchBox').removeClass('openSearch');
    }
});


// if($(window).width() < 561)
// {
//     $('.toggleSearch').on("click", function(){
//         if($('.header').hasClass('openSearch1'))
//         {
//             $('.header').removeClass('openSearch1');
//         }
//         else{
//             $('.header').addClass('openSearch1');
//         }
//     });
    
//     $(document).on("click", function (event) {
//         var $trigger = $(".header .searchBox.searchMobile");
//         if ($trigger !== event.target && !$trigger.has(event.target).length) {
//             $('.searchBox.searchMobile').removeClass('openSearch1');
//         }
//     });
// } 

// Hide / Show header Searchbar End

// select 2  dropdown 
$(document).ready(function(){
    var $disabledResults = $(".select2Custom");
    $disabledResults.select2();
    $('b[role="presentation"]').hide();
});
// select 2  dropdown End

