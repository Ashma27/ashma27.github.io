$(window).scroll(function () {
   
    if($(window).width()>=992){
    if ($(window).scrollTop() >= 1) {
        $('.header').addClass('fixedHeader');
        $('.bannerBox').css('margin-top', '94px');
    } else {
        $('.header').removeClass('fixedHeader');
        $('.bannerBox').css('margin-top', '124px');
    }
}
else {
    if ($(window).scrollTop() >= 1) {
        $('.header').addClass('fixedHeader');
        $('.bannerBox').css('margin-top', '94px');
    } else {
        $('.header').removeClass('fixedHeader');
        $('.bannerBox').css('margin-top', '94px');
    }
}
});

if($(window).width()<415){
    $('.bannerBox').css('margin-top', '84px');
    $(window).scroll(function () {
    if ($(window).scrollTop() >= 1) {
        $('.bannerBox').css('margin-top', '84px');
    }
    else{
        $('.bannerBox').css('margin-top', '84px');
    }
});
}

$('.navbar-toggler').click(function () {
    if ($(this).parents('.navbar').find('.navbar-collapse').hasClass('show')) {
        $('.navbar-expand-md .navbar-collapse').css('left', '-250px');
    } else {
        $('.navbar-expand-md .navbar-collapse').css('left', '0px');
    }
});

$(document).ready(function() {
	function scrollToSection(event) {
    event.preventDefault();
    var $section = $($(this).attr('href')); 
    $('html, body').animate({
      scrollTop: $section.offset().top-90
    }, 1300);
  }
  $('[data-scroll]').on('click', scrollToSection);
});

$(document).ready(function(){
    $('.navbar-toggler').click(function(){
        if($(this).hasClass('active'))
        {
            $(this).removeClass('active')
        }
        else{
            $(this).addClass('active')
        }
    });
});