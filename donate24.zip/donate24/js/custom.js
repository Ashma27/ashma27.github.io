// Fixed Header Start

    $(window).scroll(function () {
    
        if ($(window).scrollTop() >= 1) {
            $('.header').addClass('fixedHeader');
        } else {
            $('.header').removeClass('fixedHeader');
        }
    });
  
  // Fixed Header End

  // Sidebar Start

    $('.navbar-toggler').click(function () {
        if ($(this).parents('.navbar').find('.navbar-collapse').hasClass('show')) {
            $('.navbar-expand-md .navbar-collapse').css('left', '-250px');
        } else {
            $('.navbar-expand-md .navbar-collapse').css('left', '0px');
        }
    });
  
  // Sidebar End

  // Navbar Button Style Start

$(document).ready(function(){
    $('.navbar-toggler').click(function(){
        if($(this).hasClass('active'))
        {
            $(this).removeClass('active')
        }
        else{
            $(this).addClass('active')
        }
    });
});
  
  // Navbar Button Style End


//   Show Hide Password Start
$(document).ready(function() {
    $(".passwordField a").on('click', function(event) {
        event.preventDefault();
        if($(this).parents('.passwordField').find('input').attr("type") == "text"){
            $(this).parents('.passwordField').find('input').attr('type', 'password');
            $(this).parent('.passwordField').find('i').addClass( "fa-eye-slash" );
            $(this).parent('.passwordField').find('i').removeClass( "fa-eye" );
        }
        else if($(this).parents('.passwordField').find('input').attr("type") == "password"){
            $(this).parents('.passwordField').find('input').attr('type', 'text');
            $(this).parent('.passwordField').find('i').removeClass( "fa-eye-slash" );
            $(this).parent('.passwordField').find('i').addClass( "fa-eye" );
        }
    });
});
//   Show Hide Password End

// Show Hide Submenu Start
$(document).ready(function(){
    $('.nav-link.headMenu').on('click', function(){
        if($(this).parents('.mainMenu').find('.subMenu').hasClass('activeSubmenu')){
            $(this).parents('.mainMenu').find('.subMenu').removeClass('activeSubmenu')
            $(this).parents('.mainMenu').find('.subMenu').slideUp();
            $(this).parents('.mainMenu').removeClass('activeMenu');
        }
        else{
            $('.nav-link.headMenu').parents('.mainMenu').find('.subMenu').removeClass('activeSubmenu');
            $('.nav-link.headMenu').parents('.mainMenu').find('.subMenu').slideUp();
            $('.nav-link.headMenu').parents('.mainMenu').removeClass('activeMenu');
            $(this).parents('.mainMenu').find('.subMenu').addClass('activeSubmenu');
            $(this).parents('.mainMenu').find('.subMenu').slideDown();
            $(this).parents('.mainMenu').addClass('activeMenu');
        }
    });

    $(document).on("click", function (event) {
        var $trigger = $(".mainMenu");
        if ($trigger !== event.target && !$trigger.has(event.target).length) {
            $('.subMenu').removeClass('activeSubmenu');
            $('.mainMenu').removeClass('activeMenu');
            $('.headMenu').parents('.mainMenu').find('.subMenu').slideUp();
        }
    });

})
// Show Hide Submenu End
// Dashboard Sidebar Start
$(document).ready(function(){
    $('.dashContainer .navbar-toggler').on('click', function(){
        if($(this).hasClass('active')){
            $(this).parents('body').find('.dashboardSidenav').css('left','0px');
        }
        else{
            $(this).removeClass('active');
            $(this).parents('body').find('.dashboardSidenav').css('left','-285px');
        }
    });

});
// Dashboard Sidebar End
// Show Hide Search Box Start
$(document).ready(function(){
    $('.searchBox').on('click', function(){
        if($(this).hasClass('searchOpen')){
            $('.topSearchBox').slideUp();
            $(this).addClass('searchClose');
            $(this).removeClass('searchOpen');
        }
        else{
            $(this).addClass('searchOpen');
            $(this).removeClass('searchClose');
            $('.topSearchBox').slideDown();
        }
        
    })
})

// Show Hide Search Box End
// profile image change start 
$(document).ready(function(){
    var readURL = function(input){
        if (input.files && input.files[0]){
            var reader = new FileReader();
            reader.onload = function (e){
                $('.profile-pic').attr('src', e.target.result);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $(".file-upload").on('change', function(){
        readURL(this);
        $('.upload-button').addClass('active');
    });
    $(".upload-button").on('click', function() {
       $(".file-upload").click();
    });
});
// profile image change End

    // Modal Contact Number With Flag and Country Code Start
    $(document).ready(function(){
var input = document.querySelector("#phoneNumber");
window.intlTelInput(input, {
    nationalMode: false,
    utilsScript: "js/utils.js",
});

$('#phoneNumber').click(function() {
    var elmcode = $(this).prev('.iti__flag-container').find('ul.iti__country-list').find('.iti__active').find(".iti__dial-code").text();
    $(this).val(elmcode + ' - ');
});
});
// Modal Contact Number With Flag and Country Code End
// Sliders Start
// Browseby Slider Start
$().ready(function(){
    $('.browseBySlider').slick({
    autoplay: false,
    autoplaySpeed: 3000,
    arrows: true,
    dots: false,
    slidesToShow: 4,
    infinite: false,
    responsive: [
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 3
            }
        },
        {
            breakpoint: 768,
            settings: {
                slidesToShow: 2.7
            }
        },
        {
            breakpoint: 561,
            settings: {
                slidesToShow: 2
            }
        }
    ]
    });
});
// Browseby Slider End
// Featured Campaigns Slider Start
$().ready(function(){
    $('.featuredCampSlider').slick({
    autoplay: false,
    autoplaySpeed: 3000,
    arrows: true,
    dots: false,
    slidesToShow: 3,
    infinite: false,
    responsive: [
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 2
            }
        },
        {
            breakpoint: 561,
            settings: {
                slidesToShow: 1
            }
        }
    ]
    });
});
// Featured Campaigns Slider End
// New Campaigns Slider Start
$().ready(function(){
    $('.newCampSlider').slick({
    autoplay: false,
    autoplaySpeed: 3000,
    arrows: true,
    dots: false,
    slidesToShow: 3,
    infinite: false,
    responsive: [
        {
            breakpoint: 992,
            settings: {
                slidesToShow: 2
            }
        },
        {
            breakpoint: 561,
            settings: {
                slidesToShow: 1
            }
        }
    ]
    });
});
// New Campaigns Slider End
// Sliders End
//  Modals Hide Show Start
$(document).ready(function(){
    $('.onLogin').on('click', function(){
        $('.loginModal').modal('show');
        $('.signupModal').modal('hide');
    });
    $('.onSignup').on('click', function(){
        $('.loginModal').modal('hide');
        $('.signupModal').modal('show');
    });
    $('.onForgotPswd').on('click', function(){
        $('.loginModal').modal('hide');
        $('.forgotPswdModal').modal('show');
    });
    $('#showSuccessModal').on('click', function(){
        $('.changePwdModal').modal('hide');
        $('.successFulModal').modal('show');
    });
    
})
//  Modals Hide Show End

// contributaion class Add 
$('.contriBtn').on('click', function () {
    if($(this).hasClass('active')){
        $(this).removeClass('active');
        $(".wishBox span").html("Removed from your wishlist!. ");
    }
    else{
        $(this).addClass('active');
        $(".wishBox span").html("Added to your wishlist!. ");
    }
    $(".wishBox").fadeIn();
    $(".wishBox").fadeOut(2000);
});
// contributaion class End
// cope iframe link 
$(document).ready(function() {
var copyEmailBtn = document.querySelector('#copyLink');  
copyEmailBtn.addEventListener('click', function(event) {  
var emailLink = document.querySelector('#iframeLink');  
var range = document.createRange();  
range.selectNode(emailLink);  
window.getSelection().addRange(range);  

try{
var successful = document.execCommand('copy');  
var msg = successful ? 'successful' : 'unsuccessful';  
console.log('Copy email command was ' + msg);  
} catch(err) {  
console.log('Oops, unable to copy');  
}  
window.getSelection().removeAllRanges();  
});  
});  
// copy iframe link end 
// View more Start 
$(document).ready(function() {
    $('.donationFeeds .loadSec:hidden').slice(0, 6).show();
    $('.btn_load').click(function() {
    $('.donationFeeds .loadSec:hidden').slice(0, 2).slideDown();
    if ($('.donationFeeds .loadSec:hidden').length === 0) {
    $('.btn_load').fadeOut('fast');
    }
    });
});
// View More End


// select 2  dropdown 
$(document).ready(function(){
    var $disabledResults = $(".select2Custom");
    $disabledResults.select2();
    $('b[role="presentation"]').hide();
});
// select 2  dropdown End

// Payment Method Dropdown Show Hide Start
$(document).ready(function() {
     // payment Method
     $('input[name=paymentMethod][type="radio"]').click(function() {
        var inputValue = $(this).attr("value");
        var targetBox = $("." + inputValue);
        $("#showCCForm").not(targetBox).slideUp();
        $("#showCDForm").not(targetBox).slideUp();
        // $("#enterUpi").not(targetBox).slideUp();
        // $("#enterIb").not(targetBox).slideUp();
        $(targetBox).slideDown();

        if($(this).parents('.addBox').hasClass('methodSelect')){
            $(this).parents('.addBox').removeClass('methodSelect');
        }
        else{
            $('.addBox').removeClass('methodSelect');
            $(this).parents('.addBox').addClass('methodSelect');
        }
    });
});
// Payment Method Dropdown Show Hide End

lightGallery(document.getElementById('lightgallery'));

