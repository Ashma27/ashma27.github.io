//InfoModal Load Function Start
$(window).on('load', function () {
    $('#infoModal').modal('show');
 });
 //InfoModal Load Function End

var length = $('.buddy').length;
var current = 1;

function changeSlide(side) {
    if (side == 'prev') {
        $('#img' + current).trigger('swipeleft');
    } else {
        $('#img' + current).trigger('swiperight');
    }
}
var owl = $('.owl-carousel').owlCarousel({
    autoplay: false,
    center: true,
    loop: true,
    responsive: {
        0: {
            items: 5,
            loop: true
        },
        600: {
            items: 5,
            loop: true
        },
        1000: {
            items: 5,
            loop: true
        }
    },
    dots: false,
    touchDrag: false,
    mouseDrag: false
});

//Bonus Button Position Change
if ($(window).width() <= 560) {
	  $(".buddy").on("swipeleft", function () {
        $(this).addClass('rotate-right').delay(700).fadeOut(1);
        $('.buddy').find('.status').remove();
        if ($(this).is(':last-child')) {
            $('.buddy:nth-child(1)').removeClass('rotate-left rotate-right').fadeIn(300);
            current = 1;
            $('.buddy:nth-child(1)').removeClass('rotate-right rotate-left').fadeIn(300);
        } else {
            current++;
            $(this).next().removeClass('rotate-left rotate-right').fadeIn(400);
        }
        owl.trigger('next.owl.carousel');
        $(".rightInfo").hide();
        $("#prodDetails"+ current).show();
        console.log("prodDetails"+ current);
        $("#prodDetails"+ current).children(".bonusBtn").prependTo($("#prodDetails"+ current));
    });
	  $(".buddy").on("swiperight", function () {
        $(this).addClass('rotate-left').delay(700).fadeOut(1);
        $('.buddy').find('.status').remove();
        if (current > 1) {
            current--;
            $(this).prev().removeClass('rotate-right rotate-left').fadeIn(400);
        } else {
            current = length;
            $('.buddy:nth-child(' + length + ')').removeClass('rotate-left rotate-right').fadeIn(300);
        }
        owl.trigger('prev.owl.carousel');
        $(".rightInfo").hide();
        $("#prodDetails"+ current).show();
        $("#prodDetails"+ current).children(".bonusBtn").prependTo($("#prodDetails"+ current));
        console.log("prodDetails"+ current);
    });
    $("#prodDetails"+ current).children(".bonusBtn").prependTo($("#prodDetails"+ current));
}else{
	$(".buddy").on("swipeleft", function () {
        $(this).addClass('rotate-right').delay(700).fadeOut(1);
        $('.buddy').find('.status').remove();
        if ($(this).is(':last-child')) {
            $('.buddy:nth-child(1)').removeClass('rotate-left rotate-right').fadeIn(300);
            current = 1;
            $('.buddy:nth-child(1)').removeClass('rotate-right rotate-left').fadeIn(300);
        } else {
            current++;
            $(this).next().removeClass('rotate-left rotate-right').fadeIn(400);
        }
        owl.trigger('next.owl.carousel');
        $(".rightInfo").hide();
        $("#prodDetails"+ current).show();
        console.log("prodDetails"+ current);
    });
    $(".buddy").on("swiperight", function () {
        $(this).addClass('rotate-left').delay(700).fadeOut(1);
        $('.buddy').find('.status').remove();
        if (current > 1) {
            current--;
            $(this).prev().removeClass('rotate-right rotate-left').fadeIn(400);
        } else {
            current = length;
            $('.buddy:nth-child(' + length + ')').removeClass('rotate-left rotate-right').fadeIn(300);
        }
        owl.trigger('prev.owl.carousel');
        $(".rightInfo").hide();
        $("#prodDetails"+ current).show();
        console.log("prodDetails"+ current);
    });
}
//Bonus Button Position Change End